import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'William & Melisa | Wedding Album',
  description: 'A collection of beautiful moments from William & Melisa’s wedding, 19 December 2026.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="id"><body>{children}</body></html>;
}
