'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { isSupabaseConfigured, supabase } from '@/lib/supabase';

type Photo = { id: string; image_url: string; caption: string | null; created_at: string };

export default function Home() {
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [caption, setCaption] = useState('');
  const [selected, setSelected] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);
  const [notice, setNotice] = useState('');
  const [showQR, setShowQR] = useState(false);
  const [lightbox, setLightbox] = useState<Photo | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const [albumUrl, setAlbumUrl] = useState('');

  useEffect(() => { setAlbumUrl(window.location.href); }, []);

  const loadPhotos = useCallback(async () => {
    if (!supabase) return;
    const { data, error } = await supabase.from('photos').select('id,image_url,caption,created_at').order('created_at', { ascending: false });
    if (!error && data) setPhotos(data as Photo[]);
  }, []);

  useEffect(() => {
    loadPhotos();
    if (!supabase) return;
    const channel = supabase.channel('wedding-photos').on('postgres_changes', { event: '*', schema: 'public', table: 'photos' }, loadPhotos).subscribe();
    const timer = window.setInterval(loadPhotos, 12000);
    return () => { supabase?.removeChannel(channel); window.clearInterval(timer); };
  }, [loadPhotos]);

  function chooseFiles(files: FileList | null) {
    if (!files) return;
    const valid = Array.from(files).filter(file => file.type.startsWith('image/') && file.size <= 15 * 1024 * 1024);
    if (valid.length !== files.length) setNotice('Hanya foto maksimal 15 MB per file yang bisa diunggah.');
    setSelected(valid.slice(0, 10));
  }

  async function uploadPhotos() {
    if (!supabase || selected.length === 0) return;
    setUploading(true); setNotice('');
    let success = 0;
    for (const file of selected) {
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '-');
      const path = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}-${safeName}`;
      const { error: storageError } = await supabase.storage.from('wedding-photos').upload(path, file, { cacheControl: '3600', upsert: false, contentType: file.type });
      if (storageError) { setNotice(`Gagal mengunggah ${file.name}: ${storageError.message}`); continue; }
      const { data: publicData } = supabase.storage.from('wedding-photos').getPublicUrl(path);
      const { error: insertError } = await supabase.from('photos').insert({ image_url: publicData.publicUrl, caption: caption.trim() || null });
      if (insertError) setNotice(`Foto tersimpan di penyimpanan, tetapi gagal masuk galeri: ${insertError.message}`);
      else success++;
    }
    setUploading(false); setSelected([]); setCaption('');
    if (fileRef.current) fileRef.current.value = '';
    if (success) setNotice(`${success} foto berhasil ditambahkan ke album. Terima kasih!`);
    await loadPhotos();
  }

  return (
    <main>
      <section className="hero">
        <div className="hero-glow" />
        <div className="hero-inner">
          <p className="eyebrow">THE WEDDING OF</p>
          <h1>William <span>&</span><br className="mobile-break" /> Melisa</h1>
          <div className="ornament"><i /> <span>✦</span> <i /></div>
          <p className="date">19 · 12 · 2026</p>
          <p className="hero-note">A day to remember, moments to cherish.</p>
          <a className="scroll-link" href="#album">EXPLORE OUR ALBUM <span>↓</span></a>
        </div>
        <div className="hero-side">FOREVER STARTS HERE · 2026</div>
      </section>

      <section className="intro" id="album">
        <p className="eyebrow">OUR WEDDING MOMENTS</p>
        <h2>Captured with love<span>.</span></h2>
        <p className="intro-copy">Setiap foto menyimpan cerita. Bagikan momen indah yang kamu abadikan bersama kami.</p>
      </section>

      <section className="upload-section">
        <div className="upload-card">
          <div className="upload-icon">＋</div>
          <div className="upload-copy"><h3>Share your moments</h3><p>Unggah foto kenanganmu langsung dari HP.</p></div>
          {!isSupabaseConfigured ? (
            <div className="setup-warning">Album belum dihubungkan ke penyimpanan online. Admin perlu mengisi pengaturan Supabase terlebih dahulu (lihat README).</div>
          ) : (
            <div className="upload-form">
              <label className="file-button">{selected.length ? `${selected.length} foto dipilih` : 'Pilih foto'}<input ref={fileRef} type="file" accept="image/*" multiple onChange={e => chooseFiles(e.target.files)} /></label>
              <input className="caption-input" value={caption} onChange={e => setCaption(e.target.value)} placeholder="Tulis pesan (opsional)" maxLength={100} />
              <button className="upload-button" disabled={!selected.length || uploading} onClick={uploadPhotos}>{uploading ? 'Mengunggah…' : 'Unggah foto'}</button>
              <small>Maks. 10 foto sekali unggah · 15 MB per foto</small>
            </div>
          )}
          {notice && <p className="notice">{notice}</p>}
        </div>
      </section>

      <section className="gallery-section">
        <div className="gallery-heading"><div><p className="eyebrow">THE GALLERY</p><h2>Our memories</h2></div><span className="photo-count">{photos.length} PHOTOS</span></div>
        {photos.length ? <div className="gallery-grid">{photos.map(photo => <button className="photo-tile" key={photo.id} onClick={() => setLightbox(photo)}><img src={photo.image_url} alt={photo.caption || 'Wedding moment'} loading="lazy" />{photo.caption && <span className="photo-caption">{photo.caption}</span>}</button>)}</div> : <div className="empty-gallery"><span>✧</span><p>Our story in pictures begins here.</p><small>Foto yang diunggah akan muncul di galeri ini.</small></div>}
      </section>

      <section className="share-section"><p className="eyebrow">LET’S KEEP THE MEMORIES</p><h2>Be part of our story.</h2><p>Scan QR Code ini untuk membuka album dan berbagi foto.</p><button className="qr-button" onClick={() => setShowQR(!showQR)}>{showQR ? 'Tutup QR Code' : 'Tampilkan QR Code'}</button>{showQR && <div className="qr-panel"><QRCodeSVG value={albumUrl || 'https://example.com'} size={190} bgColor="#ffffff" fgColor="#372a2b" includeMargin /><small>Arahkan kamera HP untuk membuka album</small></div>}</section>
      <footer><div className="footer-mark">W <span>&</span> M</div><p>WITH LOVE, WILLIAM & MELISA</p><small>19 DECEMBER 2026</small></footer>

      {lightbox && <div className="lightbox" onClick={() => setLightbox(null)}><button className="close-lightbox" aria-label="Tutup">×</button><img src={lightbox.image_url} alt={lightbox.caption || 'Wedding moment'} onClick={e => e.stopPropagation()} />{lightbox.caption && <p>{lightbox.caption}</p>}</div>}
    </main>
  );
}
