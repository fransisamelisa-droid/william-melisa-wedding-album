# William & Melisa — Wedding Photo Album

Website album foto pernikahan responsif, dibuat dengan Next.js dan Supabase. Tamu dapat membuka album melalui link/QR Code, mengunggah foto dari HP, dan melihat foto yang sudah masuk. Galeri mengambil foto terbaru secara otomatis (Realtime + refresh berkala).

## 1. Siapkan database dan penyimpanan
1. Buat project di https://supabase.com/ (paket Free cukup untuk mulai).
2. Buka **SQL Editor** di Supabase.
3. Salin seluruh isi `supabase/setup.sql`, lalu tekan **Run**.
4. Buka **Project Settings → API Keys** atau dialog **Connect**. Salin **Project URL** dan **Publishable key** (`sb_publishable_...`).

## 2. Jalankan di komputer
1. Install Node.js versi 18 atau lebih baru.
2. Ekstrak ZIP ini, lalu buka terminal di folder project.
3. Jalankan `npm install`.
4. Salin `.env.example` menjadi `.env.local`.
5. Isi nilai berikut dengan data dari Supabase:

```
NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=sb_publishable_...
```

6. Jalankan `npm run dev`, lalu buka http://localhost:3000.

## 3. Publikasikan ke Vercel
1. Upload folder project ini ke repository GitHub.
2. Di Vercel pilih **Add New → Project**, lalu import repository tersebut.
3. Pada **Environment Variables**, tambahkan `NEXT_PUBLIC_SUPABASE_URL` dan `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` dengan nilai dari Supabase.
4. Tekan **Deploy**. Setelah selesai, buka domain `.vercel.app` yang diberikan.
5. QR Code pada halaman akan otomatis memakai alamat website yang sedang dibuka.

## Catatan penting
- Jangan pernah memasukkan `service_role` atau `sb_secret_...` key ke website. Gunakan hanya publishable key (`sb_publishable_...`).
- Karena ini album tamu, aturan SQL mengizinkan siapa pun yang memiliki link untuk melihat dan mengunggah foto. Bagikan link hanya kepada tamu yang diundang.
- Batas unggah pada tampilan adalah 10 foto sekali pilih dan 15 MB per foto. Untuk mencegah spam, bagikan link secara terbatas dan pantau penggunaan Storage di Supabase.
- QR Code dibuat dari URL website yang sedang dibuka, sehingga setelah deploy QR akan berisi link album yang benar.


## Konfigurasi Supabase yang sudah disiapkan
File `.env.local` di dalam ZIP sudah diisi dengan Project URL dan publishable key yang diberikan. File ini tidak ikut terunggah ke Git karena diabaikan oleh `.gitignore`. Saat deploy ke Vercel, masukkan kedua variabel tersebut secara manual pada Settings → Environment Variables.
