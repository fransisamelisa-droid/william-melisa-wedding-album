-- Jalankan seluruh SQL ini di Supabase > SQL Editor.
-- Membuat tabel daftar foto.
create table if not exists public.photos (
  id uuid primary key default gen_random_uuid(),
  image_url text not null,
  caption text,
  created_at timestamptz not null default now()
);

alter table public.photos enable row level security;

drop policy if exists "Public can view wedding photos" on public.photos;
create policy "Public can view wedding photos"
  on public.photos for select to anon, authenticated using (true);

drop policy if exists "Public can add wedding photos" on public.photos;
create policy "Public can add wedding photos"
  on public.photos for insert to anon, authenticated with check (true);

-- Membuat bucket foto publik (agar foto bisa ditampilkan di galeri).
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('wedding-photos', 'wedding-photos', true, 15728640, array['image/jpeg','image/png','image/webp','image/heic','image/heif'])
on conflict (id) do update set public = true, file_size_limit = 15728640, allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "Public can view wedding album files" on storage.objects;
create policy "Public can view wedding album files"
  on storage.objects for select to anon, authenticated using (bucket_id = 'wedding-photos');

drop policy if exists "Guests can upload wedding album files" on storage.objects;
create policy "Guests can upload wedding album files"
  on storage.objects for insert to anon, authenticated with check (bucket_id = 'wedding-photos');

-- Aktifkan Realtime untuk tabel photos agar galeri memperbarui otomatis.
do $$ begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'photos'
  ) then
    alter publication supabase_realtime add table public.photos;
  end if;
end $$;
